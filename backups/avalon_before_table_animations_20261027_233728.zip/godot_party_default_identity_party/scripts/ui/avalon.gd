extends "res://games/minigame/godot_party_default_identity_party/scripts/ui/main.gd"
## Avalon is a presentation adapter. The authoritative rules never live in this scene.
## Only a viewer-filtered session snapshot is used to draw private information.
const AVALON_ROLES = {"merlin":"梅林", "assassin":"刺客", "loyal":"忠臣", "minion":"爪牙"}
const AVALON_COPY: Dictionary[String, String] = {
	"merlin": "好人阵营，能看见邪恶玩家。你的目标是让三次远征成功，并隐藏身份，避免被刺客识破。",
	"assassin": "邪恶阵营，知道邪恶同伴。你的目标是破坏三次远征，或在三次远征成功后刺杀梅林。",
	"loyal": "好人阵营，无特殊技能。你的目标是让远征成功，防止内鬼破坏远征，并保护梅林。",
	"minion": "邪恶阵营，知道邪恶同伴。你的目标是隐藏身份，混入远征队伍，让三次远征失败。"
}
const AVALON_PHASES: Dictionary[String, String] = {
	"team_proposal": "队长提名阶段",
	"team_vote": "队伍投票阶段",
	"team_vote_result": "队伍投票结果阶段",
	"quest": "远征投票阶段",
	"quest_result": "远征结果阶段",
	"assassination": "刺杀梅林阶段",
	"ended": "本局结束"
}
const SubtitleScript: Script = preload("res://games/minigame/godot_party_default_identity_party/scripts/ui/avalon_subtitles.gd")
const PROLOGUE: Array[String] = [
	"不列颠的未来寄托于亚瑟王。他象征着繁荣希望。",
	"然而，在王麾下英勇的战士之中，潜伏着莫德雷德邪恶的追随者。",
	"唯有梅林能够识破他们的真面目，但他只能隐晦地传递自己的预言。"
]
var prologue_started: bool = false
const ACTION_PHASES: Array[String] = ["team_vote", "quest", "assassination"]
var selected_team: Array[int] = []
var selected_ballot : Variant = -1
var render_serial : Variant = 0
var status_dock: VBoxContainer
var atmosphere: Control
var last_selected_id : Variant = -1
const AtmosphereScript = preload("res://games/minigame/godot_party_default_identity_party/scripts/ui/avalon_atmosphere.gd")
const OrnamentScript = preload("res://games/minigame/godot_party_default_identity_party/scripts/ui/avalon_card_ornament.gd")

func _ready() -> void:
	super._ready()
	# Replace only Avalon's inherited background; Werewolf keeps its original art.
	for child: Variant in get_children():
		if child is TextureRect:
			child.texture = load("res://games/minigame/godot_party_default_identity_party/assets/art/avalon_lake.svg")
			child.name = "AvalonLake"
			break
	_ensure_atmosphere()

## Avalon uses a persistent caption node independent of the rebuilt table.
func _create_subtitles() -> void:
	stage = Control.new()
	stage.name = "CenterStage"
	stage.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(stage)
	subtitles = SubtitleScript.new()
	subtitles.name = "WaitingStatus"
	subtitles.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	subtitles.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitles.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	subtitles.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	subtitles.add_theme_font_override("font", title_font)
	subtitles.add_theme_color_override("font_color", PAPER)
	subtitles.add_theme_color_override("font_shadow_color", Color(0.02, 0.03, 0.05, 0.8))
	subtitles.add_theme_constant_override("shadow_offset_y", 2)
	subtitles.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stage.add_child(subtitles)
	subtitles.intro_finished.connect(_render)

func _label(text: String, size_px: int = 18, color: Color = PAPER, parent: Node = null) -> Label:
	return super._label(text, roundi(size_px * 1.12), color, parent)

func _button(text: String, callback: Callable, primary: bool = false, minimum: Vector2 = Vector2(0, 52)) -> Button:
	var button: Button = super._button(text, callback, primary, minimum * 1.08)
	button.add_theme_font_size_override("font_size", 20)
	return button

func _ensure_atmosphere() -> void:
	if is_instance_valid(atmosphere): return
	atmosphere = AtmosphereScript.new()
	atmosphere.name = "AvalonAtmosphere"
	add_child(atmosphere)
	move_child(atmosphere, 1)

func _sync_atmosphere(key: String) -> void:
	var phase : Variant = str(view.get("phase", ""))
	var success : Variant = true
	if phase == "quest_result":
		success = int(view.get("quest_fail_votes", 0)) < int(view.get("fails_required", 1))
	elif phase == "ended":
		success = view.get("winner", "") == "good"
	atmosphere.present(key, "intro" if round_start else ("exited" if exited else phase), success, reduced_motion)


func start_game(_roster: Array, _local_player_id: int = 1) -> void:
	_on_error("请通过 GodotParty 大厅开始联机对局。")

func bind_session(external_session: Node) -> void:
	if is_instance_valid(external_session) and external_session is SessionScript and external_session.game_id != "avalon":
		_on_error("这个场景只接受阿瓦隆会话，请由宿主选择对应游戏。")
		return
	selected_team.clear()
	selected_ballot = -1
	prologue_started = false
	if is_node_ready():
		subtitles.reset()
		_dismiss_modal()
	super.bind_session(external_session)

func _preset_text(count: int) -> String:
	var evil: Variant = 3 if count >= 7 else 2
	return "%d 位好人 · %d 位坏人\n含梅林与刺客" % [count - evil, evil]

func _on_view(snapshot: Dictionary) -> void:
	var previous_phase: Variant = str(view.get("phase", ""))
	var previous_leader: Variant = int(view.get("leader_id", -1))
	if snapshot.get("self_id", -1) != view.get("self_id", -1):
		selected_target = -2
		selected_ballot = -1
	view = snapshot
	var phase: Variant = str(view.get("phase", ""))
	if phase != last_phase:
		selected_target = -2
		selected_ballot = -1
		last_phase = phase
	if previous_phase != phase or previous_leader != int(view.get("leader_id", -1)):
		selected_team.clear()
	if not prologue_started and not view.is_empty():
		prologue_started = true
		if phase != "ended" and not view.get("cancelled", false):
			subtitles.begin_intro(PROLOGUE)
	page = "game"
	_render()
	if phase == "ended" and not reported_end and not exited:
		reported_end = true
		finished.emit(view.duplicate(true))

func _render() -> void:
	if not is_node_ready(): return
	render_serial += 1
	_ensure_atmosphere()
	var art_key: Variant = "%d/%s/%s/%s/%s/%s" % [match_serial, view.get("round", 0), view.get("phase", ""), view.get("leader_id", 0), round_start, exited]
	_sync_atmosphere(art_key)
	if is_instance_valid(shell):
		remove_child(shell)
		shell.queue_free()
	shell = MarginContainer.new()
	shell.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shell.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(shell)
	arena = Control.new()
	arena.mouse_filter = Control.MOUSE_FILTER_IGNORE
	shell.add_child(arena)
	_perimeter()
	root_box = _bottom_dock("ActionDock", 128, 490)
	if exited:
		if standalone_preview: root_box.add_child(_guarded_button("再来一局  →", func(): start_game(local_names), true))
	elif round_start and not view.is_empty():
		_label(_preset_text(view.get("players", []).size()), 16, TEAL, root_box)
		root_box.add_child(_guarded_button("开始本局，分发身份  →", func(): round_start = false; _render(), true))
	else: _game()
	if view.get("quest_sizes", []).size() == 5 and not view.get("phase", "") in ["", "lobby", "connecting"] and not exited:
		status_dock = _bottom_dock("QuestStatus", -490, -128)
		_status_board(status_dock)
	notice_label = _label(error_text, 14, Color("#e9ad99"), root_box)
	notice_label.visible = not error_text.is_empty()
	_present_subtitles()
	_identity_dock()
	_corner_controls()
	move_child(stage, -1)
	if is_instance_valid(modal): move_child(modal, -1)

## The local role is always visible; network snapshots define what each client knows.
func _identity_dock() -> void:
	var role: String = str(view.get("your_role", ""))
	if exited or session.self_id <= 0 or not AVALON_ROLES.has(role):
		return
	var dock: PanelContainer = PanelContainer.new()
	dock.name = "IdentityDock"
	dock.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	dock.offset_left = 20.0
	dock.offset_right = 410.0
	dock.offset_top = -188.0
	dock.offset_bottom = -20.0
	dock.grow_vertical = Control.GROW_DIRECTION_BEGIN
	dock.add_theme_stylebox_override("panel", _style(Color("#10282f"), GOLD, 5, 14))
	var parent: Control = arena
	parent.add_child(dock)
	var content: VBoxContainer = VBoxContainer.new()
	content.add_theme_constant_override("separation", 6)
	dock.add_child(content)
	var identity: Label = _label(str(AVALON_ROLES[role]), 30, GOLD, content)
	identity.name = "Role"
	var description: Label = _label(AVALON_COPY[role], 16, PAPER, content)
	description.name = "RoleDescription"
	_ignore_card_children(dock)
	dock.mouse_filter = Control.MOUSE_FILTER_IGNORE

## Keep round/phase and help available beside the main table.
func _corner_controls() -> void:
	var phase: String = str(view.get("phase", ""))
	if not AVALON_PHASES.has(phase) or exited:
		return
	var parent: Control = arena
	var progress: VBoxContainer = VBoxContainer.new()
	progress.name = "RoundPhaseDock"
	progress.position = Vector2(20, 20)
	progress.custom_minimum_size.x = 300.0
	progress.add_theme_constant_override("separation", 6)
	parent.add_child(progress)
	var round_label: Label = _label("%d/5 回合" % int(view.get("quest_number", 1)), 28, GOLD, progress)
	round_label.name = "Round"
	var phase_label: Label = _label(AVALON_PHASES[phase], 18, PAPER, progress)
	phase_label.name = "Phase"
	_ignore_card_children(progress)
	progress.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var help: Button = _guarded_button("身份百科", _show_role_guide, false, Vector2(144, 44))
	help.name = "RoleGuideButton"
	parent.add_child(help)
	help.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	help.grow_vertical = Control.GROW_DIRECTION_BEGIN
	help.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	help.offset_left = -184.0
	help.offset_right = -20.0
	help.offset_top = -78.0
	help.offset_bottom = -20.0

## The guide and private HUD share descriptions; no match identities enter this modal.
func _show_role_guide() -> void:
	_show_modal("身份百科", "了解各身份的能力与目标", [["关闭", _dismiss_modal, true]])
	modal.name = "RoleGuide"
	var content: VBoxContainer = modal.get_meta("content")
	content.get_parent().custom_minimum_size.x = 840.0
	var entries: GridContainer = GridContainer.new()
	entries.columns = 2
	entries.add_theme_constant_override("h_separation", 24)
	entries.add_theme_constant_override("v_separation", 24)
	content.add_child(entries)
	content.move_child(entries, 2)
	for role: String in AVALON_COPY:
		var entry: VBoxContainer = VBoxContainer.new()
		entry.custom_minimum_size.x = 378.0
		entry.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		entries.add_child(entry)
		_title(str(AVALON_ROLES[role]), 26, entry)
		var description: Label = _label(AVALON_COPY[role], 18, PAPER, entry)
		description.name = "Description_" + role

func _bottom_dock(node_name: String, left: float, right: float) -> VBoxContainer:
	var dock: Variant = VBoxContainer.new()
	dock.name = node_name
	dock.anchor_left = .5
	dock.anchor_right = .5
	dock.anchor_top = 1.0
	dock.anchor_bottom = 1.0
	dock.offset_left = left
	dock.offset_right = right
	dock.offset_top = -194
	dock.offset_bottom = -20
	dock.grow_vertical = Control.GROW_DIRECTION_BEGIN
	dock.add_theme_constant_override("separation", 7)
	arena.add_child(dock)
	return dock

func _status_board(parent: Node) -> void:
	var sizes: Array = view.get("quest_sizes", [])
	var results: Array = view.get("quest_results", [])
	var track: Variant = _row(parent, 8)
	for i: Variant in 5:
		var result: Variant = results[i] if i < results.size() else null
		var token: Variant = "○"
		var color: Variant = MUTED
		if result != null:
			var success: Variant = bool(result.get("success", false)) if result is Dictionary else bool(result)
			token = "✓" if success else "×"
			color = TEAL if success else Color("#e9ad99")
		var size_text: Variant = str(sizes[i]) if i < sizes.size() else "?"
		var text: Variant = _label("%d · %s\n%s 人" % [i+1, token, size_text], 14, color, track)
		text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		text.autowrap_mode = TextServer.AUTOWRAP_OFF
	_label("队长：%s · 连拒 %d / 5" % [_player_name(int(view.get("leader_id", -1))), int(view.get("rejection_count", 0))], 15, GOLD, parent)
	_label("本次 %d 人出征 · %d 张失败票判失败" % [_quest_size(), int(view.get("fails_required", 1))], 14, PAPER, parent)
	var team: Array = view.get("team", [])
	if not team.is_empty():
		var numbers: Variant = PackedStringArray()
		for id: Variant in team: numbers.append("%02d" % _seat_number(int(id)))
		_label("提名座位：" + " · ".join(numbers), 13, MUTED, parent)
	elif view.get("players", []).size() >= 7:
		_label("第 4 次任务需要 2 张失败票才失败", 13, MUTED, parent)

func _quest_size() -> int:
	if view.has("quest_size"): return int(view.quest_size)
	var sizes: Array = view.get("quest_sizes", [])
	var index: Variant = int(view.get("quest_number", view.get("round", 1))) - 1
	return int(sizes[index]) if index >= 0 and index < sizes.size() else 0

func _seat_number(id: int) -> int:
	for i: Variant in view.get("players", []).size():
		if int(view.players[i].id) == id: return i + 1
	return id

## Bind each callback to one rendered view, so stale or repeated clicks cannot
## submit another phase's action or advance two public phases.
func _guarded_button(text: String, callback: Callable, primary: bool = false, minimum: Vector2 = Vector2(0, 44)) -> Button:
	var serial: Variant = render_serial
	return _button(text, func():
		if serial == render_serial:
			callback.call(), primary, minimum)

func _can_select(p: Dictionary) -> bool:
	if session.self_id <= 0: return false
	if p.is_empty() or round_start or exited or subtitles.intro_active: return false
	if view.get("phase", "") != "team_proposal": return false
	return int(view.get("leader_id", -1)) == session.self_id and not _player(int(p.id)).is_empty()

func _toggle_team(id: int) -> void:
	if not _can_select(_player(id)): return
	if selected_team.has(id): selected_team.erase(id)
	elif selected_team.size() < _quest_size(): selected_team.append(id)
	else:
		_on_error("队伍已满，请先取消一位队员。")
		return
	error_text = ""
	last_selected_id = id if selected_team.has(id) else -1
	_render()
	if selected_team.has(id): call_deferred("_selection_flourish", id, render_serial)
	last_selected_id = -1

func _selection_flourish(id: int, serial: int) -> void:
	# Containers finish their layout after the rebuild. A stale deferred effect
	# must never appear after a phase change or a newer selection.
	if serial != render_serial or not selected_team.has(id): return
	var seat: Variant = arena.get_node_or_null("Seat%d" % id)
	if is_instance_valid(seat):
		atmosphere.select_at(seat.get_global_rect().get_center() - atmosphere.global_position)

func _perimeter() -> void:
	if view.get("phase", "") in ["", "lobby", "connecting"]: return
	var players: Array = view.get("players", [])
	if players.size() < 5 or players.size() > 8: return
	var positions: Array = {
		5: [Vector2(.37,0), Vector2(.63,0), Vector2(0,.5), Vector2(1,.5)],
		6: [Vector2(.30,0), Vector2(.50,0), Vector2(.70,0), Vector2(0,.5), Vector2(1,.5)],
		7: [Vector2(.37,0), Vector2(.63,0), Vector2(0,.34), Vector2(0,.66), Vector2(1,.34), Vector2(1,.66)],
		8: [Vector2(.30,0), Vector2(.50,0), Vector2(.70,0), Vector2(0,.34), Vector2(0,.66), Vector2(1,.34), Vector2(1,.66)]
	}.get(players.size(), [])
	var viewer: Variant = int(view.get("self_id", session.self_id))
	if _player(viewer).is_empty(): return
	var other_index: Variant = 0
	for i: Variant in players.size():
		var p: Dictionary = players[i]
		var id: Variant = int(p.id)
		var is_self: Variant = id == viewer
		var pos: Variant = Vector2(.5, 1) if is_self else positions[other_index]
		if not is_self: other_index += 1
		var selected: Variant = selected_team.has(id)
		var eligible: Variant = _can_select(p)
		var proposed: Variant = view.get("team", []).has(id)
		var box: Variant = Button.new()
		box.name = "Seat%d" % id
		box.set_meta("player_id", id)
		box.set_meta("is_self", is_self)
		box.disabled = not eligible
		box.focus_mode = Control.FOCUS_ALL if eligible else Control.FOCUS_NONE
		box.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND if eligible else Control.CURSOR_ARROW
		box.tooltip_text = "点击选择或取消「%s」，选满后在下方确认" % str(p.name) if eligible else ""
		var serial: Variant = render_serial
		box.pressed.connect(func():
			if serial == render_serial: _toggle_team(id))
		box.anchor_left = pos.x
		box.anchor_right = pos.x
		box.anchor_top = pos.y
		box.anchor_bottom = pos.y
		box.offset_left = -95
		box.offset_right = 95
		box.offset_top = -92
		box.offset_bottom = 92
		if pos.x == 0:
			box.offset_left = 20
			box.offset_right = 210
		elif pos.x == 1:
			box.offset_left = -210
			box.offset_right = -20
		if pos.y == 0:
			box.offset_top = 20
			box.offset_bottom = 204
		elif pos.y == 1:
			box.offset_top = -204
			box.offset_bottom = -20
		var card_style: Variant = _style(Color("#243b3e") if selected else Color("#10282f"), GOLD if selected or is_self else (TEAL if proposed else Color("#4a6263")), 5, 10)
		for state: Variant in ["normal", "disabled"]: box.add_theme_stylebox_override(state, card_style)
		box.add_theme_stylebox_override("hover", _style(Color("#294449"), GOLD, 5, 10))
		box.add_theme_stylebox_override("pressed", _style(Color("#263f42"), GOLD, 5, 10))
		box.add_theme_stylebox_override("focus", _style(Color.TRANSPARENT, PAPER, 5, 10))
		arena.add_child(box)
		var inset: Variant = MarginContainer.new()
		inset.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		for side: Variant in ["left", "right", "top", "bottom"]: inset.add_theme_constant_override("margin_" + side, 10)
		box.add_child(inset)
		var v: Variant = VBoxContainer.new()
		v.add_theme_constant_override("separation", 3)
		inset.add_child(v)
		var line: Variant = _row(v, 8)
		_label("%02d%s" % [i+1, " · 你" if is_self else ""], 15, GOLD, line)
		_label("队长" if int(view.get("leader_id", -1)) == id else "在席", 12, TEAL, line).horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		var portrait: Variant = TextureRect.new()
		var portrait_role: Variant = str(p.get("role", "knight")) if view.get("phase", "") == "ended" else "knight"
		portrait.texture = load("res://games/minigame/godot_party_default_identity_party/assets/art/avalon_%s.svg" % portrait_role)
		portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		portrait.custom_minimum_size.y = 36
		v.add_child(portrait)
		var name_label: Variant = _label(str(p.name), 17, PAPER, v)
		name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		name_label.autowrap_mode = TextServer.AUTOWRAP_OFF
		name_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		name_label.custom_minimum_size.x = 140
		var knowledge: String = _visible_identity(p)
		var identity_label: Label = _label(knowledge, 14, Color("#e9ad99") if knowledge in ["邪恶阵营", "邪恶同伴"] else GOLD if is_self or view.get("phase", "") == "ended" else MUTED, v)
		identity_label.name = "VisibleIdentity"
		identity_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		var footer: Variant = "等待行动"
		var tint: Variant = MUTED
		if view.get("phase", "") == "ended":
			footer = AVALON_ROLES.get(str(p.get("role", "")), "")
			tint = GOLD
		elif view.get("phase", "") == "team_vote":
			var submitted: bool = view.get("submitted_ids", []).has(id)
			footer = "已投票 ✓" if submitted else "未投票"
			tint = TEAL if submitted else MUTED
		elif eligible:
			footer = "已选择 ✓" if selected else "点击加入队伍"
			tint = GOLD if selected else TEAL
		elif view.get("phase", "") == "team_vote_result":
			var votes: Dictionary = view.get("team_votes", {})
			var vote: Variant = votes.get(str(id), null)
			if vote != null:
				footer = "赞成 ✓" if int(vote) == 1 else "反对 ×"
				tint = TEAL if int(vote) == 1 else Color("#e9ad99")
		elif proposed:
			footer = "远征队员"
			tint = TEAL
		var action_status: Label = _label(footer, 11, tint, v)
		action_status.name = "ActionStatus"
		action_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		var ornament: Variant = OrnamentScript.new()
		ornament.name = "HeraldicOrnament"
		ornament.selected = selected
		ornament.proposed = proposed
		ornament.leader = int(view.get("leader_id", -1)) == id
		ornament.reduced_motion = reduced_motion
		ornament.reveal_age = 0.0 if last_selected_id == id else 5.0
		if view.get("phase", "") == "team_vote_result":
			var public_votes: Dictionary = view.get("team_votes", {})
			ornament.ballot = int(public_votes.get(str(id), -1))
			ornament.reveal_age = atmosphere.phase_age - i * .07
		box.add_child(ornament)
		box.mouse_entered.connect(func(): ornament.set_hover(true))
		box.mouse_exited.connect(func(): ornament.set_hover(false))
		box.focus_entered.connect(func(): ornament.set_hover(true))
		box.focus_exited.connect(func(): ornament.set_hover(false))
		_ignore_card_children(box)

func _game() -> void:
	if subtitles.intro_active:
		return
	if session.self_id <= 0:
		_label("观战中 · 仅显示公开信息", 18, MUTED, root_box)
		return
	var phase: Variant = str(view.get("phase", ""))
	if phase in ["", "lobby", "connecting"]: return
	if phase == "ended":
		_label("好人获胜" if view.get("winner", "") == "good" else "邪恶获胜", 18, GOLD, root_box)
		if standalone_preview: root_box.add_child(_guarded_button("再来一局  →", func(): start_game(local_names), true))
		root_box.add_child(_guarded_button("结束本局", _leave))
		return
	if phase in ACTION_PHASES:
		var needs_action: Variant = not view.get("submitted_ids", []).has(session.self_id)
		if phase == "quest": needs_action = needs_action and view.get("team", []).has(session.self_id)
		if phase == "assassination": needs_action = str(view.get("your_role", "")) == "assassin"
		if not needs_action:
			_label("你的选择已收好。\n等待其他玩家完成。" if view.get("submitted_ids", []).has(session.self_id) else "请等待本轮行动完成。", 17, MUTED, root_box)
			return
		_action_controls()
		return
	_public_board(root_box)

## Waiting text names the acting role, never a hidden player's identity or quest ballot.
func _waiting_text() -> String:
	match str(view.get("phase", "")):
		"team_proposal":
			return "等待队长[%s]选择队员" % _player_name(int(view.get("leader_id", -1)))
		"team_vote":
			return "等待全体玩家完成队伍投票 · 已完成 %d/%d" % [view.get("submitted_ids", []).size(), view.get("players", []).size()]
		"quest":
			return "等待远征队员提交任务牌"
		"assassination":
			return "等待刺客选择目标"
		"team_vote_result":
			return "%s · 赞成 %d / 反对 %d\n3 秒后自动继续" % ["提案通过" if view.get("team_approved", false) else "提案未通过", int(view.get("team_approve_count", 0)), int(view.get("team_reject_count", 0))]
		"quest_result":
			return "%s · 成功 %d 张 / 失败 %d 张\n3 秒后自动继续" % ["远征成功" if int(view.get("quest_fail_votes", 0)) < int(view.get("fails_required", 1)) else "远征失败", int(view.get("quest_success_votes", 0)), int(view.get("quest_fail_votes", 0))]
	return ""

## The phase can change immediately; visible text changes only after its own fade.
func _present_subtitles() -> void:
	subtitles.reduced_motion = reduced_motion
	stage.anchor_left = 0.18
	stage.anchor_right = 0.82
	stage.anchor_top = 0.25 if subtitles.intro_active else 0.205
	stage.anchor_bottom = 0.65 if subtitles.intro_active else 0.305
	subtitles.add_theme_font_size_override("font_size", 40 if subtitles.intro_active else 30)
	var message: String = _waiting_text()
	if exited:
		message = "此夜的远征已落幕"
	elif view.get("phase", "") == "ended":
		message = ("圣杯之光不灭，好人获胜" if view.get("winner", "") == "good" else "暗影笼罩圆桌，邪恶获胜") + "\n" + str(view.get("last_result", ""))
	var key: String = "%d/%s/%s/%s/%s" % [match_serial, view.get("epoch", 0), view.get("phase", ""), exited, message]
	subtitles.present(key, message)

## Never infer exact roles from host state; only expose viewer-filtered knowledge.
func _visible_identity(player: Dictionary) -> String:
	var id: int = int(player.id)
	if view.get("phase", "") == "ended":
		return str(AVALON_ROLES.get(str(player.get("role", "")), "身份未知"))
	var role: String = str(view.get("your_role", ""))
	if id == session.self_id:
		return str(AVALON_ROLES.get(role, "身份未知"))
	if role == "merlin" and view.get("known_evil", []).has(id):
		return "邪恶阵营"
	if role in ["assassin", "minion"] and view.get("your_allies", []).has(id):
		return "邪恶同伴"
	return "身份未知"

## Show actions in the table's centre without covering player cards or hiding knowledge.
func _action_controls() -> void:
	var center: CenterContainer = CenterContainer.new()
	center.name = "ActionPanel"
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.offset_top = 104.0
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	arena.add_child(center)
	root_box = _panel(center, Color("#10282f"), LINE, 20)
	root_box.get_parent().custom_minimum_size = Vector2(880, 420)
	var phase: Variant = str(view.get("phase", ""))
	if phase == "assassination":
		_title("最后的一次猜测", 32, root_box)
		_label("选择一位好人，再确认刺杀。这里不会标明梅林。", 18, MUTED, root_box)
		var targets: Variant = GridContainer.new()
		targets.columns = 3
		root_box.add_child(targets)
		var allies: Array = view.get("your_allies", [])
		for p: Variant in view.get("players", []):
			var id: Variant = int(p.id)
			if id == session.self_id or allies.has(id): continue
			var target: Variant = _guarded_button("%02d · %s%s" % [_seat_number(id), str(p.name), " ✓" if selected_target == id else ""], func(): selected_target = id; _render(), selected_target == id, Vector2(236, 70))
			target.name = "AssassinationTarget%d" % id
			targets.add_child(target)
		_spacer(root_box)
		var confirm: Variant = _guarded_button("确认刺杀，揭晓终局  →", func(): _submit_action("assassinate", selected_target), true)
		confirm.disabled = selected_target < 0
		root_box.add_child(confirm)
		return
	_title("请投下你的队伍票" if phase == "team_vote" else "请放下你的任务卡", 32, root_box)
	_label("所有人投票后，队伍票将逐人公开。" if phase == "team_vote" else "任务卡只公开成功 / 失败总数，不公开谁投了哪张。", 18, MUTED, root_box)
	var team_names: Variant = PackedStringArray()
	for id: Variant in view.get("team", []): team_names.append("%02d · %s" % [_seat_number(int(id)), _player_name(int(id))])
	_label("远征队伍：" + "、".join(team_names), 17, TEAL, root_box)
	var choices: Variant = _row(root_box, 20)
	var yes: Variant = _guarded_button(("赞成队伍" if phase == "team_vote" else "任务成功") + (" ✓" if selected_ballot == 1 else ""), func(): selected_ballot = 1; _render(), selected_ballot == 1, Vector2(360, 100))
	choices.add_child(yes)
	if phase == "team_vote" or view.get("your_role", "") in ["assassin", "minion"]:
		choices.add_child(_guarded_button(("反对队伍" if phase == "team_vote" else "任务失败") + (" ✓" if selected_ballot == 0 else ""), func(): selected_ballot = 0; _render(), selected_ballot == 0, Vector2(360, 100)))
	elif phase == "quest":
		_label("好人只能选择任务成功。", 17, TEAL, root_box)
	_spacer(root_box)
	_label("尚未选择" if selected_ballot < 0 else "已经选择，确认后不可修改。", 16, GOLD, root_box)
	var confirm: Variant = _guarded_button("确认投票  →", func(): _submit_action("team_vote" if phase == "team_vote" else "quest_vote", selected_ballot), true)
	confirm.disabled = selected_ballot < 0
	root_box.add_child(confirm)

func _public_board(parent: Node) -> void:
	var phase: Variant = str(view.get("phase", ""))
	if phase == "team_proposal":
		if int(view.get("leader_id", -1)) == session.self_id:
			_label("队长选人：%d / %d · 可以选择自己" % [selected_team.size(), _quest_size()], 17, PAPER, parent)
			var confirm: Variant = _guarded_button("确认提名，开始队伍投票  →", _submit_team, true)
			confirm.disabled = selected_team.size() != _quest_size()
			parent.add_child(confirm)
		else:
			_label("等待队长「%s」提名队伍" % _player_name(int(view.get("leader_id", -1))), 17, MUTED, parent)
		return
func _submit_team() -> void:
	if view.get("phase", "") != "team_proposal" or session.self_id != int(view.get("leader_id", -1)) or selected_team.size() != _quest_size(): return
	error_text = ""
	var team: Variant = selected_team.duplicate()
	session.submit("propose_team", team)

func _submit_action(action: String, target: int = -1) -> void:
	if subtitles.intro_active or session.self_id <= 0 or str(view.get("phase", "")) not in ACTION_PHASES: return
	error_text = ""
	selected_target = -2
	selected_ballot = -1
	session.submit(action, target)
	# Clear the local choice after sending; server snapshots decide the next phase.
	_render()

func _request_leave() -> void:
	_show_modal("结束这场远征？", "退出将取消本局身份游戏，其他玩家不计胜负；由大游戏处理后续轮换。", [["继续游戏", _dismiss_modal, false], ["确认离开", func(): _dismiss_modal(); _leave(), true]])


